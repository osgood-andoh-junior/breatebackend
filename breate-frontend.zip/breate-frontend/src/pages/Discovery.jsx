import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { discoverAPI } from '../services/discover';
import { metadataAPI } from '../services/metadata';
import { UILanguage } from '../uiLanguage';
import './Discovery.css';

const Discovery = () => {
  const [activeTab, setActiveTab] = useState('users'); // 'users' or 'projects'
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [archetypes, setArchetypes] = useState([]);
  const [tiers, setTiers] = useState([]);

  // Filters
  const [userFilters, setUserFilters] = useState({
    username: '',
    archetype_id: '',
    tier_id: '',
  });
  const [projectFilters, setProjectFilters] = useState({
    archetype: '',
    region: '',
    coalition: '',
  });

  useEffect(() => {
    loadMetadata();
    loadUsers();
    loadProjects();
  }, []);

  const loadMetadata = async () => {
    try {
      const [archetypesData, tiersData] = await Promise.all([
        metadataAPI.getArchetypes(),
        metadataAPI.getTiers(),
      ]);
      setArchetypes(archetypesData);
      setTiers(tiersData);
    } catch (err) {
      console.error('Failed to load metadata:', err);
    }
  };

  const loadUsers = async () => {
    setLoading(true);
    try {
      const filters = {};
      if (userFilters.username) filters.username = userFilters.username;
      if (userFilters.archetype_id) filters.archetype_id = parseInt(userFilters.archetype_id);
      if (userFilters.tier_id) filters.tier_id = parseInt(userFilters.tier_id);

      const data = await discoverAPI.discoverUsers(filters);
      // Filter out users with "Creator" archetype and ensure all users have valid data
      const filteredUsers = data.filter(user => {
        // Exclude users with "Creator" archetype
        if (user.archetype === 'Creator') {
          return false;
        }
        // Ensure user has required fields (username is required)
        return user.username && user.id;
      });
      setUsers(filteredUsers);
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadProjects = async () => {
    setLoading(true);
    try {
      const filters = {};
      if (projectFilters.archetype) filters.archetype = projectFilters.archetype;
      if (projectFilters.region) filters.region = projectFilters.region;
      if (projectFilters.coalition) filters.coalition = projectFilters.coalition;

      const data = await discoverAPI.discoverProjects(filters);
      setProjects(data);
    } catch (err) {
      console.error('Failed to load projects:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUserFilterChange = (field, value) => {
    setUserFilters({ ...userFilters, [field]: value });
  };

  const handleProjectFilterChange = (field, value) => {
    setProjectFilters({ ...projectFilters, [field]: value });
  };

  const getUserInitials = (user) => {
    if (user.full_name) {
      const names = user.full_name.trim().split(/\s+/);
      if (names.length >= 2) {
        return (names[0][0] + names[names.length - 1][0]).toUpperCase();
      }
      return names[0][0].toUpperCase();
    }
    if (user.username) {
      return user.username.charAt(0).toUpperCase();
    }
    return '?';
  };

  useEffect(() => {
    loadUsers();
  }, [userFilters]);

  useEffect(() => {
    loadProjects();
  }, [projectFilters]);

  return (
    <div className="discovery">
      <h1>{UILanguage.general.discover}</h1>
      <div className="discovery-tabs">
        <button
          className={activeTab === 'users' ? 'active' : ''}
          onClick={() => setActiveTab('users')}
        >
          Users
        </button>
        <button
          className={activeTab === 'projects' ? 'active' : ''}
          onClick={() => setActiveTab('projects')}
        >
          Projects
        </button>
      </div>

      {activeTab === 'users' && (
        <div className="discovery-content">
          <div className="filters">
            <input
              type="text"
              placeholder="Search by username"
              value={userFilters.username}
              onChange={(e) => handleUserFilterChange('username', e.target.value)}
            />
            <select
              value={userFilters.archetype_id}
              onChange={(e) => handleUserFilterChange('archetype_id', e.target.value)}
            >
              <option value="">All Archetypes</option>
              {archetypes.map((arch) => (
                <option key={arch.id} value={arch.id}>
                  {arch.name}
                </option>
              ))}
            </select>
            <select
              value={userFilters.tier_id}
              onChange={(e) => handleUserFilterChange('tier_id', e.target.value)}
            >
              <option value="">All Tiers</option>
              {tiers.map((tier) => (
                <option key={tier.id} value={tier.id}>
                  {tier.name}
                </option>
              ))}
            </select>
          </div>

          {loading ? (
            <div className="loading-state">{UILanguage.messages.loading}</div>
          ) : users.length === 0 ? (
            <div className="empty-state">{UILanguage.emptyStates.noUsers}</div>
          ) : (
            <div className="users-grid">
              {users.map((user) => (
                <Link key={user.id} to={`/profile/${user.username}`} className="user-card">
                  <div className="user-avatar">
                    <span className="user-avatar-initials">{getUserInitials(user)}</span>
                  </div>
                  <div className="user-info">
                    <h3 className="user-name">
                      {user.full_name || user.username}
                    </h3>
                    {user.archetype && (
                      <p className="user-archetype">{user.archetype}</p>
                    )}
                    {user.next_build && (
                      <p className="user-intent">{user.next_build}</p>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'projects' && (
        <div className="discovery-content">
          <div className="filters">
            <input
              type="text"
              placeholder="Filter by archetype"
              value={projectFilters.archetype}
              onChange={(e) => handleProjectFilterChange('archetype', e.target.value)}
            />
            <input
              type="text"
              placeholder="Filter by region"
              value={projectFilters.region}
              onChange={(e) => handleProjectFilterChange('region', e.target.value)}
            />
            <input
              type="text"
              placeholder="Filter by coalition"
              value={projectFilters.coalition}
              onChange={(e) => handleProjectFilterChange('coalition', e.target.value)}
            />
          </div>

          {loading ? (
            <div>{UILanguage.messages.loading}</div>
          ) : (
            <div className="projects-list">
              {projects.map((project) => (
                <Link key={project.id} to={`/projects/${project.id}`} className="project-card">
                  <h3>{project.title}</h3>
                  <p>{project.objective}</p>
                  <div className="project-meta">
                    <span>Type: {project.project_type}</span>
                    {project.region && <span>Region: {project.region}</span>}
                    {project.needed_archetypes && (
                      <span>Needs: {project.needed_archetypes.join(', ')}</span>
                    )}
                  </div>
                </Link>
              ))}
              {projects.length === 0 && <p>{UILanguage.emptyStates.noProjectsFound}</p>}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Discovery;

